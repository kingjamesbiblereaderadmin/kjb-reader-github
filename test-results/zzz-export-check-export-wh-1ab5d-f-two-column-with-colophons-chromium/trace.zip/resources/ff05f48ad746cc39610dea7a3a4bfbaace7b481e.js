const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BRJV9g9h.js","assets/index-5ifKivQU.js","assets/index-5pMGhOmE.css"])))=>i.map(i=>d[i]);
import{aE as r,_ as t}from"./index-5ifKivQU.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-BRJV9g9h.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
