const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-wIbgzUI9.js","assets/index-WAXb40gJ.js","assets/index-BVU6bllA.css"])))=>i.map(i=>d[i]);
import{aE as r,_ as t}from"./index-WAXb40gJ.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-wIbgzUI9.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
