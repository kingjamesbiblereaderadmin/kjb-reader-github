const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C27-35k0.js","assets/index-BlnK6c6w.js","assets/index-BoZxn5my.css"])))=>i.map(i=>d[i]);
import{aD as r,_ as t}from"./index-BlnK6c6w.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-C27-35k0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
