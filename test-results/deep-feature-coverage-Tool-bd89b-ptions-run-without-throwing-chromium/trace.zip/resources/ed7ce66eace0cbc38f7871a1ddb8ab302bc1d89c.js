const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CahkW3jP.js","assets/index-rmgWWRzD.js","assets/index-YktKaQoA.css"])))=>i.map(i=>d[i]);
import{aE as r,_ as t}from"./index-rmgWWRzD.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-CahkW3jP.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
