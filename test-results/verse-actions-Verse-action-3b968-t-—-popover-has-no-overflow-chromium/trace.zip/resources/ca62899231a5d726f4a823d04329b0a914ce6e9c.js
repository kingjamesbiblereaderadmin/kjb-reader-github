const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C8amOkTC.js","assets/index-Chj_ITmk.js","assets/index-Dhy9wJwK.css"])))=>i.map(i=>d[i]);
import{aE as r,_ as t}from"./index-Chj_ITmk.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-C8amOkTC.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
