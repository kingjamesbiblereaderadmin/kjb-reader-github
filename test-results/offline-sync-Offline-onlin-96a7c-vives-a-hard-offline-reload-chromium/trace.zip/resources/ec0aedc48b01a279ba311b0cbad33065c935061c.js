const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bu12uXuE.js","assets/index-U-xWsLCc.js","assets/index-Btz457Il.css"])))=>i.map(i=>d[i]);
import{aE as r,_ as t}from"./index-U-xWsLCc.js";const i=r("ScreenOrientation",{web:()=>t(()=>import("./web-Bu12uXuE.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ScreenOrientationWeb)});export{i as ScreenOrientation};
